//
//  childStruct.swift
//  EasyLearn
//
//  Created by Victoria Marin on 14/09/24.
//

import Foundation

struct Child : Identifiable{
    var id: UUID
    let name: String
    let age: Int
    let gender: String
    let grade: Int
    let scores: [Assignment]
    let goals: [String: Int]  // Goals for subjects, e.g., ["Math": 90]
}

struct Assignment: Identifiable {
    let id = UUID()
    let name: String
    let score: Int
    let subject: String  // Added subject
}

struct ParentModel {
    let child: Child
    let subject: String
    let difficulty: Difficulty
    let contentTypes: [ContentType]
    let prompt: String
}
