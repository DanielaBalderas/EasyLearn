//
//  logoView.swift
//  EasyLearn
//
//  Created by Victoria Marin on 14/09/24.
//

import SwiftUI

struct logoView: View {
    var body: some View {
        Image("easyLearn")
        .resizable(resizingMode: .stretch)
        .aspectRatio(contentMode: .fit)
        .frame(width:190)
        
        Spacer()
    }
}

#Preview {
    logoView()
}
