import SwiftUI
import AVFoundation

struct AssignmentView: View {
    let assignment: ParentModel
    @State private var selectedAnswer: String?
    @State private var showAnswer: Bool = false
    @State private var isAnswerCorrect: Bool? = nil
    @State private var audioPlayer: AVAudioPlayer?
    
    let possibleAnswers = ["7", "8", "9", "10"] // Example answers
    
    let primaryColor = Color(hex: "#4653C3")
    let secondaryColor = Color(hex: "#EF89CA")
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                subjectView
                questionView
                answersView
                buttonsView
                
                if showAnswer {
                    answerView
                }
            }
            .padding()
        }
        .background(
            LinearGradient(gradient: Gradient(colors: [primaryColor.opacity(0.1), secondaryColor.opacity(0.1)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
        )
        .navigationTitle("Fun Assignment!")
    }
    
    var subjectView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(assignment.subject)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(primaryColor)
            
            Text("Theme: \(assignment.subject)")
                .font(.subheadline)
                .foregroundColor(secondaryColor)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    var questionView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Question")
                .font(.headline)
                .foregroundColor(primaryColor)
            
            Text(generateQuestion(from: assignment.prompt))
                .font(.body)
                .foregroundColor(.black)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    var answersView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Choose your answer")
                .font(.headline)
                .foregroundColor(primaryColor)
            
            ForEach(possibleAnswers, id: \.self) { answer in
                Button(action: {
                    selectedAnswer = answer
                }) {
                    Text(answer)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                        .background(selectedAnswer == answer ? primaryColor : Color.white)
                        .foregroundColor(selectedAnswer == answer ? .white : primaryColor)
                        .cornerRadius(20)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(primaryColor, lineWidth: 1)
                        )
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    var buttonsView: some View {
        HStack(spacing: 15) {
            Button(action: {
                guard let selectedAnswer = selectedAnswer else {
                    print("No answer selected")
                    return
                }
                let result = checkAnswer(userAnswer: selectedAnswer, correctAnswer: "8") // Assuming '8' is the correct answer
                isAnswerCorrect = result == "Correct Answer"
                showAnswer = true
            }) {
                Text("Submit")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                       startPoint: .leading,
                                       endPoint: .trailing)
                    )
                    .cornerRadius(15)
            }
            
            Button(action: {
                // Handle "I don't understand" action
            }) {
                Text("I don't understand")
                    .font(.headline)
                    .foregroundColor(primaryColor)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .overlay(
                        RoundedRectangle(cornerRadius: 15)
                            .stroke(primaryColor, lineWidth: 1)
                    )
            }
            
            Button(action: playAudio) {
                Image(systemName: "headphones")
                    .font(.title)
                    .foregroundColor(.white)
                    .frame(width: 50, height: 50)
                    .background(
                        LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .cornerRadius(25)
            }
        }
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    var answerView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(isAnswerCorrect == true ? "Correct Answer" : "Wrong Answer")
                .font(.headline)
                .foregroundColor(primaryColor)
            
            Text(isAnswerCorrect == true ? generateAnswer(from: assignment.prompt) : "Try again.")
                .font(.body)
                .foregroundColor(.black)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(secondaryColor.opacity(0.2))
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    private func generateQuestion(from prompt: String) -> String {
        "What is \(prompt)?"
    }
    
    private func generateAnswer(from prompt: String) -> String {
        "The answer to \(prompt) is 8."
    }
    
    func checkAnswer(userAnswer: String, correctAnswer: String) -> String {
        // Define the maximum number of attempts
        let maxAttempts = 3
        var attempts = 0
        
        while attempts < maxAttempts {
            if userAnswer == correctAnswer {
                return "Correct Answer"
            } else {
                attempts += 1
                print("Wrong Answer. Try again.")
                // Simulate getting a new answer, if this was real, prompt user again
                // For now, we just stop after the first wrong attempt
                break
            }
        }
        
        return "Wrong Answer after \(maxAttempts) attempts."
    }
    
    private func playAudio() {
        // Implement audio playback logic here
        print("Playing audio...")
    }
}

struct AssignmentView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AssignmentView(assignment: ParentModel(
                child: Child(id: UUID(), name: "Alice", age: 8, gender: "Female", grade: 3, scores: [], goals: [:]),
                subject: "Math",
                difficulty: .medium,
                contentTypes: [.audio, .image],
                prompt: "5 + 3"
            ))
        }
    }
}
