import SwiftUI

struct MyChildrenView: View {
    let myChildren = [
        Child(id: UUID(), name: "Daniela", age: 6, gender: "Female", grade: 4, scores: [
            Assignment(name: "Math Assignment 1", score: 8, subject: "Math"),
            Assignment(name: "Math Assignment 2", score: 9, subject: "Math"),
            Assignment(name: "Spanish Assignment 1", score: 7, subject: "Spanish"),
            Assignment(name: "English Assignment 1", score: 8, subject: "English"),
            Assignment(name: "Math Assignment 3", score: 10, subject: "Math")
        ], goals: ["Math": 90, "Spanish": 80, "English": 85]),
        Child(id: UUID(), name: "Nancy", age: 8, gender: "Female", grade: 2, scores: [
            Assignment(name: "Math Assignment 1", score: 5, subject: "Math"),
            Assignment(name: "Math Assignment 2", score: 6, subject: "Math"),
            Assignment(name: "Spanish Assignment 1", score: 6, subject: "Spanish"),
            Assignment(name: "English Assignment 1", score: 7, subject: "English"),
            Assignment(name: "Math Assignment 3", score: 6, subject: "Math")
        ], goals: ["Math": 70, "Spanish": 75, "English": 80])
    ]

    var body: some View {
        NavigationView {
            VStack(alignment: .center, spacing:3) {
                logoView() // Assuming you have a logo view
                
                ScrollView {
                    VStack(spacing: 15) {
                        NavigationLink(destination: PromptView(children: myChildren)) {
                            Text("Create New Assignment")
                                .font(.headline)
                                .fontWeight(.semibold)
                                .padding([.top, .leading, .bottom], 8)
                                .frame(width: 310)
                                .background(Color(red: 0.0/255, green: 59.0/255, blue: 92.0/255))
                                .cornerRadius(8)
                                .foregroundColor(.white)
                        }
                        .frame(width: 200.0)
                        
                        ForEach(myChildren) { child in
                            ChildCardRowView(child: child)
                                .padding(.horizontal)
                        }
                    }
                }
                .padding(.top, 0.01)
            }
            .background(Color(red: 228/255, green: 235/255, blue: 230/255))
            .navigationTitle("My Children")
        }
    }
}

struct MyChildrenView_Previews: PreviewProvider {
    static var previews: some View {
        MyChildrenView()
    }
}
