import SwiftUI
import Charts

struct ChildCardView: View {
    let child: Child
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                headerView
                subjectKPIView
                progressChartView
                recentScoresView
            }
            .padding()
        }
        .background(Color(red: 0.95, green: 0.97, blue: 0.98))
        .offset(y:-78)
    }
    
    private var headerView: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(child.name)
                    .font(.title)
                    .fontWeight(.bold)
                Text("Grade \(child.grade) • Age \(child.age)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 60, height: 60)
                .foregroundColor(.blue)
        }
    }
    
    private var subjectKPIView: some View {
        HStack {
            ForEach(Array(child.goals.keys), id: \.self) { subject in
                KPICard(subject: subject, average: averageScore(for: subject), goal: child.goals[subject] ?? 0)
            }
        }
    }
    
    private var progressChartView: some View {
        VStack(alignment: .leading) {
            Text("Overall Progress")
                .font(.headline)
                .padding(.bottom, 8)
            
            Chart {
                ForEach(Array(child.goals.keys), id: \.self) { subject in
                    BarMark(
                        x: .value("Subject", subject),
                        y: .value("Score", averageScore(for: subject))
                    )
                    .foregroundStyle(by: .value("Subject", subject))
                }
            }
            .frame(height: 200)
            .chartXAxis {
                AxisMarks(values: .automatic) { _ in
                    AxisValueLabel()
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
    }
    
    private var recentScoresView: some View {
        VStack(alignment: .leading) {
            Text("Recent Scores")
                .font(.headline)
                .padding(.bottom, 8)
            
            ForEach(child.scores.prefix(5)) { assignment in
                HStack {
                    Text(assignment.name)
                    Spacer()
                    Text("\(assignment.score)")
                        .fontWeight(.bold)
                }
                .padding(.vertical, 4)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
    }
    
    private func averageScore(for subject: String) -> Double {
        let subjectScores = child.scores.filter { $0.subject == subject }
        let total = subjectScores.reduce(0) { $0 + $1.score }
        return subjectScores.isEmpty ? 0 : Double(total) / Double(subjectScores.count)
    }
}

struct KPICard: View {
    let subject: String
    let average: Double
    let goal: Int
    
    var body: some View {
        VStack {
            Text(subject)
                .font(.caption)
                .fontWeight(.medium)
            Text(String(format: "%.1f", average))
                .font(.title2)
                .fontWeight(.bold)
            Text("Goal: \(goal)")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

struct ChildCardView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ChildCardView(child: Child(
                id: UUID(),
                name: "Alex Johnson",
                age: 9,
                gender: "Male",
                grade: 4,
                scores: [
                    Assignment(name: "Math Quiz 1", score: 85, subject: "Math"),
                    Assignment(name: "English Essay", score: 92, subject: "English"),
                    Assignment(name: "Science Project", score: 88, subject: "Science"),
                    Assignment(name: "Math Quiz 2", score: 90, subject: "Math"),
                    Assignment(name: "History Test", score: 95, subject: "History")
                ],
                goals: ["Math": 90, "English": 85, "Science": 88, "History": 92]
            ))
        }
    }
}

// Keep the existing MyChildrenView, ChildCardRowView, and other structs as they are
