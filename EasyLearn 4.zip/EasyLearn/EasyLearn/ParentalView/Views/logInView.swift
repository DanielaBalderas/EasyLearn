import SwiftUI
import Foundation

struct LoginView: View {
    @State private var usuario: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String? = nil
    @State private var isLoggedIn: Bool = false  // Track login status
    
    // Hardcoded user credentials
    let hardcodedUser = "Victoria"
    let hardcodedPassword = "123password"
    
    var body: some View {
        VStack {
            if isLoggedIn {
                // Navigate to MyChildrenView when logged in
                MyChildrenView()
            } else {
                VStack {
                    Image("easyLearn")
                        .resizable(resizingMode: .stretch)
                        .aspectRatio(contentMode: .fit)
                        .padding(.horizontal)
                        .frame(width: 330)
                    
                    HStack { Spacer() }
                    Text("Usuario")
                        .multilineTextAlignment(.leading)
                        .bold()
                        .padding(.leading, -177.0)
                    
                    TextField("Usuario", text: $usuario)
                        .padding(.bottom)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                        .foregroundColor(.black)
                    
                    Text("Contraseña")
                        .multilineTextAlignment(.leading)
                        .bold()
                        .padding(.leading, -177.0)
                    
                    SecureField("Contraseña", text: $password)
                        .padding(.bottom)
                        .textFieldStyle(.roundedBorder)
                        .foregroundColor(.black)
                    
                    // Error message display
                    if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .bold()
                            .padding(.top, 10)
                    }
                    
                    HStack {
                        Button(action: {
                            // Login logic
                            if usuario == hardcodedUser && password == hardcodedPassword {
                                errorMessage = nil
                                isLoggedIn = true  // Change state to navigate to the new view
                            } else {
                                errorMessage = "Usuario o contraseña incorrectos."
                            }
                        }) {
                            Text("Iniciar sesión")
                                .font(.headline)
                                .fontWeight(.bold)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color(red: 70/255, green: 83/255, blue: 195/255))
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding(.top, 1.0)
                    Spacer()
                }
                .padding()
                .background(Color(red: 232/255, green: 233/255, blue: 237/255))
            }
        }
    }
}

#Preview {
    LoginView()
}
