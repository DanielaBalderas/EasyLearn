import SwiftUI

enum Difficulty: String, CaseIterable, Identifiable {
    case easy, medium, hard
    var id: String { self.rawValue }
}

enum ContentType: String, CaseIterable, Identifiable {
    case audio, image, text
    var id: String { self.rawValue }
    
    var icon: String {
        switch self {
        case .audio: return "headphones"
        case .image: return "photo"
        case .text: return "doc.text"
        }
    }
}

struct PromptView: View {
    @StateObject private var openAIService = OpenAIService()
    @State private var selectedChild: Child?
    @State private var selectedSubject = "Math"
    @State private var selectedDifficulty: Difficulty = .medium
    @State private var selectedContentType: ContentType = .text
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var generatedAssignment: Tarea?
    
    let subjects = ["Math", "Spanish", "English"]
    let children: [Child] // Assume this is passed in or fetched
    
    let primaryColor = Color(hex: "4653C3")
    let secondaryColor = Color(hex: "EF89CA")
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 25) {
                    childSelectionView
                    subjectSelectionView
                    difficultySelectionView
                    contentTypeSelectionView
                    createHomeworkButton
                    
                    if isLoading {
                        ProgressView("Generating homework...")
                    } else if let tarea = generatedAssignment {
                        NavigationLink(destination: AssignmentView(
                            child: tarea.child,  // Pass the child property of tarea
                            subject: selectedSubject,
                            difficulty: selectedDifficulty.rawValue,
                            contentType: selectedContentType.rawValue
                        )) {
                            Text("Go to Assignment")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                                   startPoint: .leading,
                                                   endPoint: .trailing)
                                )
                                .cornerRadius(15)
                                .shadow(color: primaryColor.opacity(0.3), radius: 5, x: 0, y: 2)
                        }
                    } else if let errorMessage = errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }

                }
                .padding()
            }
            .background(
                LinearGradient(gradient: Gradient(colors: [primaryColor.opacity(0.1), secondaryColor.opacity(0.1)]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
            )
            .navigationTitle("Create Homework")
        }
    }
    
    private var childSelectionView: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Select Child")
                .font(.headline)
                .foregroundColor(primaryColor)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    ForEach(children) { child in
                        ChildButton(child: child,
                                    isSelected: selectedChild?.id == child.id,
                                    primaryColor: primaryColor,
                                    secondaryColor: secondaryColor) {
                            selectedChild = child
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
    
    private var subjectSelectionView: some View {
        StringSelectionView(title: "Select Subject", options: subjects, selection: $selectedSubject, color: primaryColor)
    }
    
    private var difficultySelectionView: some View {
        SelectionView<Difficulty>(title: "Select Difficulty",
                                  options: Difficulty.allCases.map { $0.rawValue.capitalized },
                                  selection: $selectedDifficulty,
                                  color: secondaryColor)
    }
    
    private var contentTypeSelectionView: some View {
        SelectionView<ContentType>(title: "Select Content Type",
                                   options: ContentType.allCases.map { $0.rawValue.capitalized },
                                   selection: $selectedContentType,
                                   color: primaryColor)
    }
    
    private var createHomeworkButton: some View {
        Button(action: generateHomework) {
            Text("Create Homework")
                .font(.headline)
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                   startPoint: .leading,
                                   endPoint: .trailing)
                )
                .cornerRadius(15)
                .shadow(color: primaryColor.opacity(0.3), radius: 5, x: 0, y: 2)
        }
        .disabled(selectedChild == nil)
        .opacity(selectedChild == nil ? 0.6 : 1)
    }
    
    private func generateHomework() {
            guard let child = selectedChild else { return }
            
            isLoading = true
            errorMessage = nil
            generatedAssignment = nil
            
            Task {
                do {
                    let assignment = try await openAIService.generateAssignment(
                        for: child,
                        subject: selectedSubject,
                        difficulty: selectedDifficulty.rawValue,
                        contentType: selectedContentType.rawValue
                    )
                    DispatchQueue.main.async {
                        self.generatedAssignment = assignment
                        self.isLoading = false
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.errorMessage = "Failed to generate assignment: \(error.localizedDescription)"
                        self.isLoading = false
                    }
                }
            }
    }
}


struct SelectionView<T: Hashable & CaseIterable & RawRepresentable>: View where T.RawValue == String {
    let title: String
    let options: [String]
    @Binding var selection: T
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(title)
                .font(.headline)
                .foregroundColor(color)
            
            HStack(spacing: 10) {
                ForEach(options, id: \.self) { option in
                    Button(action: {
                        if let newSelection = T(rawValue: option.lowercased()) {
                            selection = newSelection
                        }
                    }) {
                        Text(option)
                            .padding(.vertical, 8)
                            .frame(maxWidth: .infinity)
                            .background(selection.rawValue == option.lowercased() ? color : Color.white)
                            .foregroundColor(selection.rawValue == option.lowercased() ? .white : color)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(color, lineWidth: 1)
                            )
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct StringSelectionView: View {
    let title: String
    let options: [String]
    @Binding var selection: String
    let color: Color
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text(title)
                .font(.headline)
                .foregroundColor(color)
            
            HStack(spacing: 10) {
                ForEach(options, id: \.self) { option in
                    Button(action: {
                        selection = option
                    }) {
                        Text(option)
                            .padding(.vertical, 8)
                            .frame(maxWidth: .infinity)
                            .background(selection == option ? color : Color.white)
                            .foregroundColor(selection == option ? .white : color)
                            .cornerRadius(20)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(color, lineWidth: 1)
                            )
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    }
}

struct ChildButton: View {
    let child: Child
    let isSelected: Bool
    let primaryColor: Color
    let secondaryColor: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .foregroundColor(isSelected ? primaryColor : .gray.opacity(0.5))
                
                Text(child.name)
                    .font(.caption)
                    .foregroundColor(isSelected ? primaryColor : .black)
            }
        }
        .padding(10)
        .background(isSelected ? secondaryColor.opacity(0.2) : Color.clear)
        .cornerRadius(10)
    }
}

struct ContentTypeButton: View {
    let contentType: ContentType
    let isSelected: Bool
    let primaryColor: Color
    let secondaryColor: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: contentType.icon)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 24)
                Text(contentType.rawValue.capitalized)
                    .font(.caption)
            }
            .foregroundColor(isSelected ? .white : primaryColor)
            .padding()
            .background(
                ZStack {
                    if isSelected {
                        LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]), startPoint: .topLeading, endPoint: .bottomTrailing)
                    } else {
                        Color.white
                    }
                }
            )
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(primaryColor.opacity(0.3), lineWidth: 1)
            )
        }
    }
}

struct PromptView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            PromptView(children: [
                Child(id: UUID(), name: "Alice", age: 8, gender: "Female", grade: 3, scores: [], goals: [:]),
                Child(id: UUID(), name: "Bob", age: 10, gender: "Male", grade: 5, scores: [], goals: [:])
            ])
        }
    }
}
