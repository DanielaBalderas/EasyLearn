import Foundation
import SwiftUI
import AVFoundation

// Define your OpenAIService class here
class OpenAIService: ObservableObject {
    private let apiKey = "-" // Replace with your actual API key
    private let apiUrl = "https://fridaplatform.com/generate"
    
    func generateAssignment(for child: Child, subject: String, difficulty: String, contentType: String) async throws -> Tarea {
        let prompt = """
        Generate a \(subject) question for a \(child.grade)th grade student.
        Difficulty: \(difficulty)
        Content Type: \(contentType)
        Include 4 possible answers, the correct answer, and a brief explanation.
        Format the response as JSON with the following structure:
        {
            "question": "...",
            "answers": ["...", "...", "...", "..."],
            "correctAnswer": "...",
            "explanation": "..."
        }
        """
        
        let parameters: [String: Any] = [
            "inputs":prompt,
                "parameters":[
                    "max_new_tokens":400
                ],
                "stream":false
        ]
        
        guard let url = URL(string: apiUrl) else {
            print ("errorCase")
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
//        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters)
        } catch {
            throw NSError(domain: "OpenAIService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Failed to serialize request parameters"])
        }
        
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let temp = response as? HTTPURLResponse{
                print(temp.statusCode)
            }
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                throw URLError(.badServerResponse)
            }
        
            guard let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] else {
                        throw NSError(domain: "OpenAIService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Failed to parse JSON response"])
                    }
                    print("JSON response:\(jsonResponse)")
                    // Access 'generated_text' from the dictionary
                    guard let choices = jsonResponse["generated_text"] as? [[String: Any]],
                          let generatedText = choices.first?["generated_text"] as? String else {
                        throw NSError(domain: "OpenAIService", code: 4, userInfo: [NSLocalizedDescriptionKey: "No generated text found"])
                    }
                    print(choices)
                    // Clean up the generated text and convert to data
                    let cleanedText = generatedText.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard let jsonData = cleanedText.data(using: .utf8) else {
                        throw NSError(domain: "OpenAIService", code: 5, userInfo: [NSLocalizedDescriptionKey: "Failed to convert string to data"])
                    }
                    
                    // Decode the assignment data from the JSON string
                    let assignment = try JSONDecoder().decode(Tarea.self, from: jsonData)
                    return assignment
             
        } catch {
            print("Request failed with error: \(error)")
            throw error
        }
    }

    
    struct OpenAIResponse: Codable {
        let generated_text: String
    }
    

}

struct AssignmentView: View {
    let child: Child
    let subject: String
    let difficulty: String
    let contentType: String
    
    @StateObject private var openAIService = OpenAIService()
    @State private var assignment: Tarea?
    @State private var selectedAnswer: String?
    @State private var showAnswer: Bool = false
    @State private var isAnswerCorrect: Bool? = nil
    @State private var isLoading: Bool = true
    @State private var errorMessage: String?
    
    let primaryColor = Color(hex: "#4653C3")
    let secondaryColor = Color(hex: "#EF89CA")
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                Text("\(subject) Assignment")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(primaryColor)
                
                if isLoading {
                    ProgressView("Loading assignment...")
                } else if let assignment = assignment {
                    Text("Question: \(assignment.question)")
                        .font(.body)
                        .foregroundColor(.black)
                    
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Choose your answer")
                            .font(.headline)
                            .foregroundColor(primaryColor)
                        
                        ForEach(assignment.answers, id: \.self) { answer in
                            Button(action: {
                                selectedAnswer = answer
                            }) {
                                Text(answer)
                                    .padding(.vertical, 8)
                                    .frame(maxWidth: .infinity)
                                    .background(selectedAnswer == answer ? primaryColor : Color.white)
                                    .foregroundColor(selectedAnswer == answer ? .white : primaryColor)
                                    .cornerRadius(20)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(primaryColor, lineWidth: 1)
                                    )
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                    
                    if showAnswer {
                        Text(isAnswerCorrect == true ? "Correct Answer" : "Wrong Answer")
                            .font(.headline)
                            .foregroundColor(isAnswerCorrect == true ? .green : .red)
                        
                        Text(isAnswerCorrect == true ? "Great job!" : "Try again.")
                            .font(.body)
                            .foregroundColor(.black)
                        
                        if isAnswerCorrect == false {
                            Text(assignment.explanation)
                                .font(.body)
                                .foregroundColor(.black)
                                .padding()
                                .background(Color.white)
                                .cornerRadius(15)
                                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                        }
                    }
                    
                    HStack(spacing: 15) {
                        Button(action: checkAnswer) {
                            Text("Submit")
                                .font(.headline)
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                                   startPoint: .leading,
                                                   endPoint: .trailing)
                                )
                                .cornerRadius(15)
                        }
                        .disabled(selectedAnswer == nil)
                        
                        Button(action: showExplanation) {
                            Text("I don't understand")
                                .font(.headline)
                                .foregroundColor(primaryColor)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.white)
                                .cornerRadius(15)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 15)
                                        .stroke(primaryColor, lineWidth: 1)
                                )
                        }
                        
                        Button(action: playAudio) {
                            Image(systemName: "headphones")
                                .font(.title)
                                .foregroundColor(.white)
                                .frame(width: 50, height: 50)
                                .background(
                                    LinearGradient(gradient: Gradient(colors: [primaryColor, secondaryColor]),
                                                   startPoint: .topLeading,
                                                   endPoint: .bottomTrailing)
                                )
                                .cornerRadius(25)
                        }
                    }
                    .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
                } else if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                }
            }
            .padding()
        }
        .background(
            LinearGradient(gradient: Gradient(colors: [primaryColor.opacity(0.1), secondaryColor.opacity(0.1)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
        )
        .navigationTitle("Fun Assignment!")
        .onAppear(perform: fetchAssignment)
    }
    
    private func fetchAssignment() {
        Task {
            do {
                isLoading = true
                assignment = try await openAIService.generateAssignment(for: child, subject: subject, difficulty: difficulty, contentType: contentType)
                isLoading = false
            } catch {
                isLoading = false
                errorMessage = "Failed to load assignment: \(error.localizedDescription)"
            }
        }
    }
    
    private func checkAnswer() {
        guard let selectedAnswer = selectedAnswer else { return }
        if selectedAnswer == assignment?.correctAnswer {
            isAnswerCorrect = true
        } else {
            isAnswerCorrect = false
        }
        showAnswer = true
    }
    
    private func showExplanation() {
        showAnswer = true
        isAnswerCorrect = false
    }
    
    private func playAudio() {
        // Placeholder for audio logic
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        AssignmentView(child: Child(id: UUID(), name: "Victoria", age: 7, gender: "Female", grade: 6, scores: [], goals: [:]), subject: "Spanish", difficulty: "Easy", contentType: "Multiplication")
    }
}

