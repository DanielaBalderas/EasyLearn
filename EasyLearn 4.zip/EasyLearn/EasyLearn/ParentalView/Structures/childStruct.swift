//
//  childStruct.swift
//  EasyLearn
//
//  Created by Victoria Marin on 14/09/24.
//

import Foundation

struct Child: Identifiable, Codable, Equatable {
    var id: UUID
    let name: String
    let age: Int
    let gender: String
    let grade: Int
    let scores: [Assignment]
    let goals: [String: Int]
    static func == (lhs: Child, rhs: Child) -> Bool {
        return lhs.id == rhs.id &&
               lhs.name == rhs.name &&
               lhs.age == rhs.age &&
               lhs.gender == rhs.gender &&
               lhs.grade == rhs.grade &&
               lhs.scores == rhs.scores &&
               lhs.goals == rhs.goals
    }
}


struct Assignment: Identifiable, Codable, Equatable {
    var id = UUID()
    let name: String
    let score: Int
    let subject: String

    static func == (lhs: Assignment, rhs: Assignment) -> Bool {
        return lhs.id == rhs.id &&
               lhs.name == rhs.name &&
               lhs.score == rhs.score &&
               lhs.subject == rhs.subject
    }
}


struct ParentModel {
    let child: Child
    let subject: String
    let difficulty: Difficulty
    let contentTypes: [ContentType]
    let prompt: String
}

struct QuizAssignment: Codable {
    let question: String
    let answers: [String]
    let correctAnswer: String
    let explanation: String
}

struct Tarea: Codable, Equatable {
    static func == (lhs: Tarea, rhs: Tarea) -> Bool {
        return lhs.child == rhs.child &&
               lhs.question == rhs.question &&
               lhs.answers == rhs.answers &&
               lhs.correctAnswer == rhs.correctAnswer &&
               lhs.explanation == rhs.explanation
    }
    
    let child: Child
    let question: String
    let answers: [String]
    let correctAnswer: String
    let explanation: String
}

