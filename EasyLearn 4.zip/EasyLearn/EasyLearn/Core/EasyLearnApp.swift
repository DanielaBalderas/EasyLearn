//
//  EasyLearnApp.swift
//  EasyLearn
//
//  Created by Victoria Marin on 14/09/24.
//

import SwiftUI

@main
struct EasyLearnApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
