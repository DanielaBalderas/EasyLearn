//import Foundation
//
//class OpenAIService: ObservableObject {
//    private let apiKey = "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"
//    private let apiUrl = "https://api.openai.com/v1/completions"
//    
//    func generateAssignment(for child: Child, subject: String, difficulty: String, contentType: String) async throws -> Assignment {
//        let prompt = """
//        Generate a \(subject) question for a \(child.grade)th grade student.
//        Difficulty: \(difficulty)
//        Content Type: \(contentType)
//        Include 4 possible answers, the correct answer, and a brief explanation.
//        Format the response as JSON with the following structure:
//        {
//            "question": "...",
//            "answers": ["...", "...", "...", "..."],
//            "correctAnswer": "...",
//            "explanation": "..."
//        }
//        """
//        
//        let parameters: [String: Any] = [
//            "model": "text-davinci-002",
//            "prompt": prompt,
//            "max_tokens": 300,
//            "temperature": 0.7
//        ]
//        
//        var request = URLRequest(url: URL(string: apiUrl)!)
//        request.httpMethod = "POST"
//        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
//        request.httpBody = try? JSONSerialization.data(withJSONObject: parameters)
//        
//        let (data, _) = try await URLSession.shared.data(for: request)
//        let decodedResponse = try JSONDecoder().decode(OpenAIResponse.self, from: data)
//        
//        guard let jsonString = decodedResponse.choices.first?.text,
//              let jsonData = jsonString.data(using: .utf8),
//              let assignment = try? JSONDecoder().decode(QuizAssignment.self, from: jsonData) else {
//            throw NSError(domain: "OpenAIService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Failed to parse assignment data"])
//        }
//        
//        return assignment
//    }
//}
//
//
//
//struct OpenAIResponse: Codable {
//    let choices: [Choice]
//}
//
//struct Choice: Codable {
//    let text: String
//}
